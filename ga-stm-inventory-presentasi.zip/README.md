# GA STM Inventory - Presentasi
Prototype aplikasi monitoring persediaan untuk presentasi:
- Login GA STM
- Dashboard total stok, masuk, keluar, perlu pesan, stok habis
- Data Barang: stok awal, masuk, keluar, stok saat ini, batas pesan
- Filter tanggal transaksi
- Barang masuk/keluar dengan tanggal
- Perlu Dipesan otomatis
- Laporan berdasarkan periode tanggal
- Cetak / Simpan PDF
Akun presentasi: admin / admin123
