# GA STM - Sistem Informasi Inventory
Versi presentasi:
- Halaman awal menggunakan logo STM
- Tidak ada akun admin/password bawaan
- Pengguna membuat akun sendiri
- Pilih jumlah pengguna 1-10 orang
- Setiap pengguna memiliki nama, username, password, dan role
- Dashboard stok
- Barang masuk/keluar dengan tanggal
- Data barang menampilkan stok awal, masuk, keluar, stok saat ini
- Perlu dipesan otomatis
- Laporan dan filter tanggal
